﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ass1
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection("Data Source= DESKTOP-LQ1SO6G\\SQLEXPRESS; Initial Catalog=Homework;Integrated Security=True");
        // SqlConnection con = new SqlConnection("Data Source=DESKTOP-LQ1SO6G\\SQLEXPRESS;Initial Catalog=Homework;Integrated Security=True");
        SqlDataAdapter da = new SqlDataAdapter();
        SqlDataAdapter dat = new SqlDataAdapter();
        SqlCommandBuilder builder;
        DataSet ds = new DataSet();

        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string sqlCommand = "SELECT * FROM Teams";

            SqlCommand getTeams = new SqlCommand(sqlCommand, con);
            dat = new SqlDataAdapter(getTeams);
            dat.Fill(ds, "Teams");
            teamGrid.DataSource = ds.Tables["Teams"];

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.playersTableAdapter.FillBy(this.homeworkDataSet.Players);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void playerGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < teamGrid.Rows.Count - 1)
            {
                var id = teamGrid.Rows[e.RowIndex].Cells[0].Value;

                string sqlCommand = "SELECT * FROM Players WHERE team_id = " + id;

                SqlCommand getPlayersByTeam = new SqlCommand(sqlCommand, con);
                getPlayersByTeam.Parameters.AddWithValue("@team_id", id);

                ds = new DataSet();
                da = new SqlDataAdapter(getPlayersByTeam);
                da.Fill(ds, "Players");
                playerGrid.DataSource = ds.Tables["Players"];
            }
        }

        private void teamGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            playerGrid_CellClick(sender, e);
        }

        private void editButton_Click(object sender, EventArgs e)
        {
           try{
                playerGrid.EndEdit();
                if (ds.HasChanges()){
                    SqlCommandBuilder builder = new SqlCommandBuilder(da);
                    //dat.Update(ds, "Teams");
                    foreach (DataRow row in ds.Tables["Players"].Rows){

                        if (row.RowState == DataRowState.Deleted) {
                            //in the DataRowCollection
                            var playerId = row["player_id", DataRowVersion.Original];
                            DeleteRelatedPositions(playerId);
                            row.Delete();
                        }
                    }
                    da.Update(ds, "Players");
                    MessageBox.Show("Changes saved");
                } else {
                    MessageBox.Show("No changes to save");
                }
            } catch (Exception ex){
                MessageBox.Show("Error on edit: " + ex.Message);
            }
        }

        private void DeleteRelatedPositions(object playerId){
            //MessageBox.Show("aici");
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-LQ1SO6G\\SQLEXPRESS;Initial Catalog=Homework;Integrated Security=True")){
                con.Open();
                string sqlCommand = "DELETE FROM MergedPlayersPositions WHERE player_id = @player_id";
                using (SqlCommand deletePositions = new SqlCommand(sqlCommand, con)){
                    deletePositions.Parameters.AddWithValue("@player_id", playerId);
                    deletePositions.ExecuteNonQuery();
                }
            }
        } 
    }
}
